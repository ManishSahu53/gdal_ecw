//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEUNIT("..\..\src\cmsxform.c");
USEUNIT("..\..\src\cmscnvrt.c");
USEUNIT("..\..\src\cmserr.c");
USEUNIT("..\..\src\cmsgamma.c");
USEUNIT("..\..\src\cmsgmt.c");
USEUNIT("..\..\src\cmsintrp.c");
USEUNIT("..\..\src\cmsio1.c");
USEUNIT("..\..\src\cmslut.c");
USEUNIT("..\..\src\cmsmatsh.c");
USEUNIT("..\..\src\cmsmtrx.c");
USEUNIT("..\..\src\cmspack.c");
USEUNIT("..\..\src\cmspcs.c");
USEUNIT("..\..\src\cmssamp.c");
USEUNIT("..\..\src\cmswtpnt.c");
USEUNIT("..\..\src\cmscam97.c");
USEUNIT("..\..\src\cmscam02.c");
USEUNIT("..\..\src\cmsps2.c");
USEUNIT("..\..\src\cmsnamed.c");
USEUNIT("..\..\src\cmsvirt.c");
USEUNIT("..\..\src\cmscgats.c");
//---------------------------------------------------------------------------
#define Library

// To add a file to the library use the Project menu 'Add to Project'.

